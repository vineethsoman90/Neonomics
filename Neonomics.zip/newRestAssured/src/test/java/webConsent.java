import java.util.concurrent.TimeUnit;

import org.apache.xpath.objects.XBoolean;
import org.apache.xpath.objects.XString;
    import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
    import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class webConsent {
    public static boolean main(String test){
        String  test1 = test;
         boolean result;
        //Setting the driver path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vineeth.Soman\\Downloads\\chromdriver\\chromedriver.exe");
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("disable-extensions");
        opt.addArguments("--start-fullscreen");
        WebDriver driver = new ChromeDriver(opt);
        driver.get(test1);

        WebElement userName = driver.findElement(By.xpath("//*[@id='username']"));
        WebElement passWord = driver.findElement(By.xpath("//*[@id='password']"));
        WebElement login = driver.findElement(By.xpath("//*[@id='kc-login']"));
        userName.sendKeys("vineethsoman@gmail.com");
        passWord.sendKeys("infY@9538");

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

             login.click();

        String webout =      driver.findElement(By.tagName("body")).getText();
        if (webout.contains("successfully")) {
            System.out.println("Consent Granted");
            result = true;
            driver.quit();
        }
        else
        {
            System.out.println("Something went wrong");
            result = false;
            driver.quit();
        }
            return result;


    }}
