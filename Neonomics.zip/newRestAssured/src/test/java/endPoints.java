public class endPoints {


    String tokenUrl = "https://sandbox.neonomics.io/auth/realms/sandbox/protocol/openid-connect/token";
    String banksUrl = "https://sandbox.neonomics.io/ics/v3/banks";
    String sessionIdUrl = "https://sandbox.neonomics.io/ics/v3/session";
    String bankAccountsUrl = "https://sandbox.neonomics.io/ics/v3/accounts";
}
