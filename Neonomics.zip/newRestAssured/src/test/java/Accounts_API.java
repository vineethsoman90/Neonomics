import static io.restassured.RestAssured.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import io.restassured.path.json.JsonPath;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.*;

public class Accounts_API {
    endPoints E = new endPoints();

    @Test

    void Test_End_to_End() throws IOException {

        Response response = given().log().all().
                headers("Content-Type","application/x-www-form-urlencoded").
                baseUri(E.tokenUrl).
                formParam("grant_type","client_credentials").
                formParam("client_id","b26946ca-bb94-4c68-83ac-23043ea084ad").
                formParam("client_secret","c3c7c57b-7ad5-4acd-9d8a-4bf480c656bb").
                when().
                post();
        System.out.println(response.jsonPath());
        JsonPath jresponse = response.jsonPath();
        System.out.println("session" + jresponse.get("session_state"));
        System.out.println("Response body: " + response.body().asString());
        String  token = jresponse.get("access_token");

        Response banksresponse = given().log().all().
                headers("Authorization", "Bearer " + token).
                headers("x-device-id","device1").
                baseUri(E.banksUrl).
                when().
                get();
        System.out.println(banksresponse.getStatusCode());
        JsonPath evaluate = banksresponse.jsonPath();
        String value = evaluate.getString("find {it.bankDisplayName == 'Justo Bank'}.id");
        List<String> blist = evaluate.getList("id");
        System.out.println(blist);
        String jsonBody = new String(Files.readAllBytes(Paths.get("C:\\Users\\Vineeth.Soman\\IdeaProjects\\newRestAssured\\src\\test\\Json Files\\bankId.json")));
        JSONObject requestParams = new JSONObject(jsonBody);
        requestParams.put("bankId",value);
        System.out.println(requestParams);
        String jbody = new String(String.valueOf((requestParams)));
        Response sessionresponse = given().log().all().
                header("Authorization", "Bearer " + token).
                header("x-device-id","device1").
                header("content-type","application/json").
                header("accept","application/json").
                contentType(ContentType.JSON).
                body(jbody).
                baseUri(E.sessionIdUrl).
                contentType("application/json").
                when().
                post();

        System.out.println("Sessionresponse body: " + sessionresponse.body().asString());
        String sessionId = sessionresponse.jsonPath().getJsonObject("sessionId");
        Response consentTry = given().log().all().
                header("Authorization", "Bearer " + token).
                header("x-device-id","device1").
                header("content-type","application/json").
                header("accept","application/json").
                header("x-psu-ip-address","109.74.179.3").
                header("x-session-id",sessionId).
                contentType(ContentType.JSON).
                baseUri(E.bankAccountsUrl).
                contentType("application/json").
                when().
                get();


        System.out.println("consent try respone: " + consentTry.body().asString());
        System.out.println(consentTry.getStatusCode());
        JsonPath    newc  = consentTry.jsonPath();
        System.out.println(newc);
        String consentUrl = consentTry.jsonPath().get("links.find {it.type == 'GET'}.href");
            System.out.println(consentUrl);
            Response getConsent = given().log().all().
                    queryParam("scope","accounts").
                    header("Authorization", "Bearer " + token).
                    header("x-device-id","device1").
                    header("content-type","application/json").
                    header("accept","application/json").
                    header("x-psu-ip-address","109.74.179.3").
                    header("x-session-id",sessionId).
                    contentType(ContentType.JSON).
                    baseUri(consentUrl).
                    contentType("application/json").
                    when().
                    get();

            System.out.println(" get consent url respone: " + getConsent.body().asString());
            String webconsenturl = getConsent.jsonPath().get("links.find {it.type == 'GET'}.href");
            //websele.main(webconsenturl);
            if (webConsent.main(webconsenturl))
        {
            Response Accounts = given().log().all().
                    header("Authorization", "Bearer " + token).
                    header("x-device-id","device1").
                    header("content-type","application/json").
                    header("accept","application/json").
                    header("x-psu-ip-address","109.74.179.3").
                    header("x-session-id",sessionId).
                    contentType(ContentType.JSON).
                    baseUri(E.bankAccountsUrl).
                    contentType("application/json").
                    when().
                    get();
            System.out.println(" Accounts respone: " + Accounts.body().asString());
            System.out.println(" before");
            JsonPath  jAccounts = Accounts.jsonPath();
            System.out.println(" before2");
            ArrayList jsone = Accounts.path("accountName");
            System.out.println(jsone.get(0));
            Assert.assertEquals(jsone.get(0),"vineethsoman@gmail.com");

        }
    }

    @Test

    void Test_Invalid_ClientId() throws IOException {

        Response response = given().log().all().
                headers("Content-Type", "application/x-www-form-urlencoded").
                baseUri(E.tokenUrl).
                formParam("grant_type", "client_credentials").
                formParam("client_id", "b26946ca-bb94-4c68-83ac-23043ea084a").
                formParam("client_secret", "c3c7c57b-7ad5-4acd-9d8a-4bf480c656bb").
                when().
                post();
        JsonPath  jresponse = response.jsonPath();
        String errorCode = jresponse.get("errorCode");
        Assert.assertEquals(errorCode,"2005");
        String errorMessage = jresponse.get("message");
        Assert.assertEquals(errorMessage,"Invalid client id/secret");

        System.out.println(" Error respone: " + response.body().asString());

    }

        @Test

    void Test_Invalid_ClientSecret() throws IOException {

        Response response = given().log().all().
                headers("Content-Type", "application/x-www-form-urlencoded").
                baseUri(E.tokenUrl).
                formParam("grant_type", "client_credentials").
                formParam("client_id", "b26946ca-bb94-4c68-83ac-23043ea084ad").
                formParam("client_secret", "c3c7c57b-7ad5-4acd-9d8a-4bf480c656b").
                when().
                post();
        JsonPath  jresponse = response.jsonPath();
        String errorCode = jresponse.get("errorCode");
        Assert.assertEquals(errorCode,"2005");
        String errorMessage = jresponse.get("message");
        Assert.assertEquals(errorMessage,"Invalid client id/secret");

        System.out.println(" Error respone: " + response.body().asString());

    }}